package com.arun.killme.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.arun.killme.model.Customer;
import com.arun.killme.service.CustomerService;

@Controller
public class HomeController {
	@Autowired
	CustomerService customerService;
	//first mapping on startup
	@RequestMapping("/")
	public ModelAndView disHome()
	{
		System.out.println("Killer entered Home");
		return new ModelAndView("enterHome");
	}
	//mapping when killer clicks sign in
	@RequestMapping("/CheckCustomer")
	public ModelAndView checkCus(Principal principal)
	{
		System.out.println("Customer Name"+principal.getName());
		return new ModelAndView("CheckCustomer");
	}
	@RequestMapping("/login")
	public String loginMethod()
	{
		return "login";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request)
	{
		request.getSession().invalidate();
		System.out.println("logout page called");

		return "logout";
		
	}
	@RequestMapping("/CheckAdmin")
	public ModelAndView checkAd(Principal principal)
	{
		System.out.println("Admin Name"+principal.getName());
		return new ModelAndView("CheckAdmin");
	}
	@RequestMapping("/toSignIn")
	public ModelAndView disSignIn()
	{
		System.out.println("Killer signing in");
		return new ModelAndView("enterSignIn");
	}
	//mapping when killer clicks sign up
	@RequestMapping("toSignUp")
	public ModelAndView disSignUp()
	{
		Customer customer = new Customer();
		System.out.println("Killer registering");
		return new ModelAndView("enterSignUp","CusKey",customer);
	}
	//Mapping when customer enter details and clicks register
	@RequestMapping("toSuccess")
	public ModelAndView disRegistered(@Valid@ModelAttribute("CusKey") Customer customer,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			return new ModelAndView("enterSignUp");
		}
	
		System.out.println(customer.getName());
		System.out.println(customer.getPassword());
		customerService.addCustomer(customer);
		return new ModelAndView("enterSignUp");
	}
	@RequestMapping("toContactUs")
	public ModelAndView disContactUs()
	{
		return new ModelAndView("ContactUs");
	}
	@RequestMapping("toAboutUs")
	public ModelAndView disAboutUs()
	{
		return new ModelAndView("AboutUs");
	}
}
