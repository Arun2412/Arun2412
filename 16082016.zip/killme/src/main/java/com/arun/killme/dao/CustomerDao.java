package com.arun.killme.dao;

import java.util.List;

import com.arun.killme.model.Customer;

public interface CustomerDao {
	
	void addCustomer(Customer customer);
	List<Customer> viewCustomer();

}
