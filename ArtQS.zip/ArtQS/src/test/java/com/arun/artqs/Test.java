package com.arun.artqs;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.arun.artqs");
		context.refresh();
		Category category = (Category) context.getBean("category");
		category.setId("001");
		category.setName("name01");
		category.setDescription("description01");
		System.out.println(category.getId());
		System.out.println(category.getName());
		System.out.println(category.getDescription());

	}

}
