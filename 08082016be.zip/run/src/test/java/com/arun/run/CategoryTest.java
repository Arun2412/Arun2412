package com.arun.run;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.arun.run.dao.CategoryDAO;
import com.arun.run.model.Category;

public class CategoryTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.arun.run");
		context.refresh();
		
		
	   CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	   
	   Category category = 	(Category) context.getBean("category");
	   /*
	   category.setId("3");
	   category.setName("3name");
	   category.setDescription("3desc");
	   
	   
	   categoryDAO.saveOrUpdate(category);
	   */
	   //categoryDAO.get("3");
	   categoryDAO.delete("3");
		
		
		
	}

}


