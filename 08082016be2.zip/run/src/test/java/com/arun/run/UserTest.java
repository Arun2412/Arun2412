package com.arun.run;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.arun.run.dao.SupplierDAO;
import com.arun.run.dao.UserDAO;
import com.arun.run.model.Supplier;
import com.arun.run.model.User;

public class UserTest {

	public static void main(String[] args) {
AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.arun.run");
		context.refresh();
		
		
	   UserDAO userDAO = (UserDAO) context.getBean("userDAO");
	   
	   User user = 	(User) context.getBean("user");
	   /*
	   user.setId("3");
	   user.setUsername("3username");
	   user.setPassword("3password");
	   user.setMobile("3mobile");
	   user.setMailid("3mailid");
	   user.setAddress("3address");
	   
	   userDAO.saveOrUpdate(user);
	   */
	   userDAO.delete("3");

	}

}
