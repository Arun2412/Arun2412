package com.arun.run;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.arun.run.dao.ProductDAO;
import com.arun.run.dao.SupplierDAO;
import com.arun.run.model.Product;
import com.arun.run.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.arun.run");
		context.refresh();
		
		
	   SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
	   
	   Supplier supplier = 	(Supplier) context.getBean("supplier");
	  /*
	   supplier.setId("1");
	   supplier.setName("1name");
	   supplier.setDescription("1desc");
	   supplier.setAddress("1address");
	   
	   supplierDAO.saveOrUpdate(supplier);
	   */
	   supplierDAO.delete("3");

	}

}
