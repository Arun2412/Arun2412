package com.arun.run;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.arun.run.dao.CategoryDAO;
import com.arun.run.dao.ProductDAO;
import com.arun.run.model.Category;
import com.arun.run.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		
AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.arun.run");
		context.refresh();
		
		
	   ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
	   
	   Product product = 	(Product) context.getBean("product");
	   /*
	   product.setId("3");
	   product.setName("3name");
	   product.setDescription("3desc");
	   product.setPrice(9999);
	   
	   productDAO.saveOrUpdate(product);
	   */
	   productDAO.delete("3");

	}

}
