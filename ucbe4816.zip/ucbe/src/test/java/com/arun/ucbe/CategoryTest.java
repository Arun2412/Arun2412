package com.arun.ucbe;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.arun.ucbe.dao.CategoryDAO;
import com.arun.ucbe.model.Category;

public class CategoryTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.arun.ucbe");
		context.refresh();
		
		
	   CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	   
	   Category category = 	(Category) context.getBean("category");
	   category.setId("2");
	   category.setName("2name");
	   category.setDescription("2desc");
	   
	   
	   categoryDAO.saveOrUpdate(category);
		
		
		
	}

}


