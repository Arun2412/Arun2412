package com.arun.killme.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.validation.Valid;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.arun.killme.model.AddItem;
import com.arun.killme.model.Customer;
import com.arun.killme.service.AddItemService;
import com.arun.killme.service.CustomerService;

@Controller
public class AdminController {
	@Autowired
	CustomerService customerService;
	
	@Autowired
	AddItemService addItemService;
	
	@RequestMapping("/toViewItems")
	public ModelAndView disAddItem()
	{
		AddItem addItem = new AddItem();
		return new ModelAndView("addItem","addItemKey",addItem);
		
	}
	@RequestMapping("/toSuccessAdd")
	public ModelAndView disAdded(@Valid@ModelAttribute("addItemKey") AddItem addItem,@RequestParam("file") MultipartFile file, BindingResult bindingResult) throws IllegalStateException, IOException
	{
		if(bindingResult.hasErrors())
		{
			System.out.println("has errors");
			return new ModelAndView("addItem");
		}
		System.out.println("added successfully");
		addItemService.addMyItem(addItem);
		MultipartFile itemImage = addItem.getFile();
		Path path = Paths.get("E://saisirwork//killme//src//main//webapp//resources//images//"+addItem.getId()+".jpg");
		if(itemImage != null && !itemImage.isEmpty())
		{
			itemImage.transferTo(new File(path.toString()));
		}
		return new ModelAndView("ex");
	}
	@RequestMapping("/toViewCustomers")
	public ModelAndView disCustomers() throws JsonGenerationException, JsonMappingException, IOException
	{
		List<Customer> list = customerService.viewCustomer();
		System.out.println("All Killers List:"+list);
		ObjectMapper mapper = new ObjectMapper();
		String listJSON = mapper.writeValueAsString(list);
		return new ModelAndView("ViewCustomers","allCustomers",listJSON);
		
	}
	@RequestMapping("/toViewAllItems")
	public ModelAndView disItems() throws JsonGenerationException, JsonMappingException, IOException
	{
		List<AddItem> list = addItemService.viewItems();
		System.out.println("All Killong items List:"+list);
		ObjectMapper mapper = new ObjectMapper();
		String listJSON = mapper.writeValueAsString(list);
		return new ModelAndView("ViewItems","allItems",listJSON);
	}
	@RequestMapping("toDeleteItem")
	public ModelAndView disDeleteItem(@RequestParam("id") int id)
	{
		addItemService.deleteItem(id);
		return new ModelAndView("deleted");
	}
}
