package com.arun.killme.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.arun.killme.model.AddItem;
import com.arun.killme.model.Customer;
import com.arun.killme.service.AddItemService;
import com.arun.killme.service.CategoryService;
import com.arun.killme.service.CustomerService;

@Controller
public class HomeController {
	@Autowired
	CustomerService customerService;
	@Autowired
	AddItemService addItemService;
	@Autowired
	CategoryService categoryService;
	//first mapping on startup
	@RequestMapping("/")
	public ModelAndView disHome()
	{
		System.out.println("Killer entered Home");
		return new ModelAndView("enterHome");
	}
	//mapping when killer clicks sign in
	@RequestMapping("/CheckCustomer")
	public ModelAndView checkCus(Principal principal)
	{
		System.out.println("Customer Name"+principal.getName());
		return new ModelAndView("CheckCustomer");
	}
	@RequestMapping("/login")
	public String loginMethod()
	{
		return "login";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request)
	{
		request.getSession().invalidate();
		System.out.println("logout page called");

		return "logout";
		
	}
	@RequestMapping("/CheckAdmin")
	public ModelAndView checkAd(Principal principal)
	{
		System.out.println("Admin Name"+principal.getName());
		return new ModelAndView("CheckAdmin");
	}
	//mapping when killer clicks sign up
	@RequestMapping("toSignUp")
	public ModelAndView disSignUp()
	{
		Customer customer = new Customer();
		System.out.println("Killer registering");
		return new ModelAndView("enterSignUp","CusKey",customer);
	}
	//Mapping when customer enter details and clicks register
	@RequestMapping("toSuccess")
	public ModelAndView disRegistered(@Valid@ModelAttribute("CusKey") Customer customer,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{
			return new ModelAndView("enterSignUp");
		}
	
		System.out.println(customer.getName());
		System.out.println(customer.getPassword());
		customerService.addCustomer(customer);
		return new ModelAndView("enterSignUp");
	}
	@RequestMapping("toContactUs")
	public ModelAndView disContactUs()
	{
		return new ModelAndView("ContactUs");
	}
	@RequestMapping("toAboutUs")
	public ModelAndView disAboutUs()
	{
		return new ModelAndView("AboutUs");
	}
	@RequestMapping("/toViewCategories")
	public ModelAndView disItems() throws JsonGenerationException, JsonMappingException, IOException
	{
		List<AddItem> list = addItemService.viewItems();
		System.out.println("All Killing items List:"+list);
		ObjectMapper mapper = new ObjectMapper();
		String listJSON = mapper.writeValueAsString(list);
		return new ModelAndView("grid","allItems",listJSON);
	}
	@RequestMapping("/viewSingleItem")
	public ModelAndView disSingleItem(@RequestParam("id") String id)
	{
		AddItem addItem =addItemService.getItemById(Integer.parseInt(id));
		return new ModelAndView("SingleItem","addItemKey",addItem);
		
	}
	@RequestMapping("/toViewCategoryWise")
	public ModelAndView disCategory(@RequestParam("category") String category) throws JsonGenerationException, JsonMappingException, IOException
	{
		System.out.println(category);
		List<AddItem> list = categoryService.getElementByCategory(category);
		ObjectMapper mapper = new ObjectMapper();
		String listJSON = mapper.writeValueAsString(list);
		System.out.println(listJSON);
		return new ModelAndView("CategoryView","CategoryKey",listJSON);
	}
}
