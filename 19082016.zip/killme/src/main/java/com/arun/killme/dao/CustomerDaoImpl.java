package com.arun.killme.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.arun.killme.model.Customer;
import com.arun.killme.model.UserRole;
@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	SessionFactory sessionFactory;
	public void addCustomer(Customer customer) {
		//create a session from session factory
		Session session = sessionFactory.getCurrentSession();
		//in session begin a transaction
		Transaction transaction = session.beginTransaction();
		customer.setEnabled(true);
		session.save(customer);
		UserRole userRole = new UserRole();
		userRole.setAuthority("ROLE_USER");
		userRole.setId(customer.getId());
		session.save(userRole);
		//in session end a transaction
		transaction.commit();

	}
	public List<Customer> viewCustomer() 
	{
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		List<Customer> list = session.createCriteria(Customer.class).list();
		transaction.commit();
		return list;		
	}
	 

}
