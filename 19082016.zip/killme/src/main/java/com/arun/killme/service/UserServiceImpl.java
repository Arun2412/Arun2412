package com.arun.killme.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arun.killme.dao.UserDao;
import com.arun.killme.model.AddItem;
import com.arun.killme.model.Drawings;
@Service
public class UserServiceImpl implements UserDao 
{
	@Autowired
	UserDao userDao;
	public List<Drawings> viewDrawings()
	{
		userDao.viewDrawings();
		return null;
	}

}
