package com.arun.killme.dao;

import java.util.List;

import com.arun.killme.model.AddItem;
import com.arun.killme.model.Drawings;

public interface UserDao 
{
	List<Drawings> viewDrawings();

}
