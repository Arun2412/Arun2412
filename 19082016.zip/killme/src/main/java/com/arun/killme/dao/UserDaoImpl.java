package com.arun.killme.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.arun.killme.model.Drawings;

@Repository
public class UserDaoImpl implements UserDao 
{
	@Autowired
	SessionFactory sessionFactory;
	
	public List<Drawings> viewDrawings() 
	{
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		List<Drawings> list = session.createCriteria(Drawings.class).list();
		transaction.commit();
		return list;	
	}

}
