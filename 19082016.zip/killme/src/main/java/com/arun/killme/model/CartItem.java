package com.arun.killme.model;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class CartItem 
{
	private int cartItemId;
	private AddItem addItem;
	private int quantity;
	private double totalPrice;
	@ManyToOne
	@JoinColumn(name="cartId")
	private Cart cart;
	
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public AddItem getAddItem() {
		return addItem;
	}
	public void setAddItem(AddItem addItem) {
		this.addItem = addItem;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	

}
