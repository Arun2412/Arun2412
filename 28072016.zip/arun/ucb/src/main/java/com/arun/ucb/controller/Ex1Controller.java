package com.arun.ucb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Ex1Controller {
	
	ModelAndView home;
	@RequestMapping("/")
	public ModelAndView displayHome(){
		home = new ModelAndView("Homepage");
		return home;
		
	}

}
