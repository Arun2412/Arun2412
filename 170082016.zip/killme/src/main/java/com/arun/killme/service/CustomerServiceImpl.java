package com.arun.killme.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.arun.killme.dao.CustomerDao;
import com.arun.killme.model.Customer;
@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerdao;
	
	public void addCustomer(Customer customer) {
		customerdao.addCustomer(customer);
		

	}
	public List<Customer> viewCustomer() {
		List<Customer> list = customerdao.viewCustomer();
		return list;
	}

}
