package com.arun.killme.service;

import java.util.List;

import com.arun.killme.model.Customer;

public interface CustomerService {
	
	void addCustomer(Customer customer);
	List<Customer> viewCustomer();

}
