package com.arun.killme.test;

import com.arun.killme.model.Customer;
import com.arun.killme.controller.*;

public class CustomerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Customer c = new Customer();
		
		System.out.println(customer.getName());
		System.out.println(customer.getEmail());
		System.out.println(customer.getMobile());
		System.out.println(customer.getAddress());
		*/
	}

}
