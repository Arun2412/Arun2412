package com.arun.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HomeController 
{
	ModelAndView mv;
	

	@RequestMapping(value="/")
	
	public ModelAndView MyHome()
	{
		mv = new ModelAndView("Homepage");
		return mv;
		
	}
	
}
